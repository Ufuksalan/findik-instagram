# Fındık Instagram Otomatik Paylaşım – Kurulum

## 1. Instagram hesabını hazırla
- Hesabı **Business (İşletme)** türüne çevir (Ayarlar → Hesap türü).
- Bir **Facebook Sayfası** oluştur ve Instagram hesabına bağla.

## 2. Meta API anahtarı al
1. developers.facebook.com → uygulama oluştur (tür: Business).
2. "Instagram Graph API" ürününü ekle.
3. Graph API Explorer'dan şu izinlerle token üret:
   `instagram_basic`, `instagram_content_publish`, `pages_show_list`, `pages_read_engagement`
4. Token'ı uzun ömürlüye çevir (kısa token → long-lived user token → `/me/accounts` ile
   sayfa token'ı; sayfa token'ı süresiz geçerlidir).
5. `IG_USER_ID`: `GET /{sayfa-id}?fields=instagram_business_account` ile bulunur.

## 3. GitHub'a yükle
1. github.com'da **public** bir repo aç (görseller Instagram'ın erişebilmesi için
   herkese açık URL'de olmalı) ve bu klasörün içeriğini yükle.
2. `images/` klasörüne **JPG** reklam görsellerini koy (01.jpg, 02.jpg, ...).
3. `posts.json` içindeki görsel adlarını ve açıklamaları kendi içeriğinle değiştir.
4. Repo → Settings → Secrets and variables → Actions:
   - `IG_USER_ID`
   - `IG_ACCESS_TOKEN`
5. Actions sekmesinden "Günlük Instagram Paylaşımı" → **Run workflow** ile test et.

Sonrası otomatik: her sabah 09:00'da (TR) sıradaki görsel paylaşılır, liste bitince başa döner.

## Notlar
- GitHub zamanlayıcısı bazen 5–20 dk gecikebilir.
- Görsel formatı JPG, oran 4:5 ile 1.91:1 arası olmalı. Günde en fazla 25 API paylaşımı.
